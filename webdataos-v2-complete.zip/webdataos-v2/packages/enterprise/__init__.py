"""Enterprise intelligence package definitions."""
