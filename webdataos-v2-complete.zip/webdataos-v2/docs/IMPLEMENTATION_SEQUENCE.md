# Implementation Sequence

1. Build Track 3 Gateway first.
   - Bright Data wrappers
   - Failure detection
   - Recovery router
   - Clean JSON output
   - Receipts/traces/metrics

2. Build Track 2 Intelligence Layer.
   - Topic registry
   - Source discovery
   - Structured records
   - Freshness/change detection
   - Context-aware retrieval
   - Neo4j graph projection

3. Build Track 1 Agent.
   - Planner
   - Retrieval-first context check
   - Live refresh when stale/missing
   - Reasoning and synthesis
   - Sourced final report

4. Build frontend dashboard.
   - Research console
   - Agent plan
   - Intelligence records
   - Gateway recovery trace

5. Build deployment and observability.
   - Docker Compose
   - Prometheus metrics
   - OpenTelemetry traces
   - Grafana dashboard placeholder

## Production hardening pass added

- API key authentication and local/dev bypass switch.
- Rate limiting and request body size guard.
- Bright Data retry, timeout, and circuit-breaker handling.
- Alembic migration scaffold.
- CI workflow for Python and TypeScript SDK.
- Production deployment checklist and API key documentation.
- SDK endpoint alignment with `/intelligence/*` API routes.
